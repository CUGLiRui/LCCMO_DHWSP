function [p_chrom,w_chrom,f_chrom]=RandomInitial(popsize)
global N NS NM F;
p_chrom=zeros(popsize,N);
f_chrom=zeros(popsize,N);%工序码
P=ones(1,N);FChrom=zeros(1,N);
for i=1:N
    P(i)=i;
    FChrom(i)=mod(i,F);%0表示分到工厂1,1表示分到工厂2 或者反过来，反正是不一样的工厂。工厂的机器是一样的。
    if FChrom(i)==0
        FChrom(i)=F;
    end
end
p_chrom(1,:)=P(randperm(N));
f_chrom(1,:)=FChrom(randperm(length(FChrom)));%将工序码打乱
for i=2:popsize
    P=p_chrom(i-1,:);
    p_chrom(i,:)=P(randperm(N));
    tmp2=f_chrom(i-1,:);
    f_chrom(i,:)=tmp2(randperm(length(tmp2)));%再根据上一个生成后续的种群个体
end

w_chrom=zeros(popsize,N,NS);
for i=1:popsize
    for j=1:N
        for k=1:NS
            w_chrom(i,j,k)=ceil(rand*NM(k));
        end
    end
end

end