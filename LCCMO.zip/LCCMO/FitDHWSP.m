function [fit1,fit2,fit3]=FitDHWSP(p_chrom,w_chrom,f_chrom)
global N TM time F;

P=cell(F,1);
FJ=cell(F,1);
for i=1:N
    t1=p_chrom(i);%记录到当前是那个工
    t3=f_chrom(t1);
    P{t3}=[P{t3} p_chrom(i)];    
end
for i=1:N
    t3=f_chrom(i);
    FJ{t3}=[FJ{t3} i];    
end
sub_f_fit=zeros(F,2);
for f=1:F
    [sub_f_fit(f,1),sub_f_fit(f,2)]=FitWSP(P{f,1},w_chrom,FJ{f,1},f);
end
fit1=sub_f_fit(1,1);
fit3=1;fit2=0;
for f=1:F
    fit2=sub_f_fit(f,2)+fit2;
    if fit1<sub_f_fit(f,1)
        fit1=sub_f_fit(f,1);
        fit3=f;
    end
end
end


function [Cmax,TEC]=FitWSP(p_chrom,w_chrom,FJ,f_index)
global NS NM stime ptime F;
N=length(FJ);
finish=zeros(N,NS);
start=zeros(N,NS);


Basic_P=5;Idle_P=0.36;
SetUp_P=10;Welding_P=28;

Basic_E=0;Idle_E=0;
SetUp_E=0;Welding_E=0;
totalidletime=0;
Kw=0.8;

for k=1:NS
    for i=1:N
        t=p_chrom(i);
        worker_n=w_chrom(1,p_chrom(i),k);
        weld_time=ptime(f_index,k,t)/worker_n;
        if k==1
            if i~=1                
                t2=(i-1);
                start(i,k)=finish(t2,k);
                finish(i,k)=start(i,k)+stime(f_index,k,t)+weld_time;
                SetUp_E=SetUp_E+stime(f_index,k,t)*SetUp_P;
            else
               finish(i,k)=start(i,k)+weld_time;
            end
            Welding_E=Welding_E+(Idle_P*(1-Kw)+Welding_P*Kw)*weld_time*(worker_n*(1+0.5*log(worker_n))); %1+0.5*ln(x)           
        else   
            if i==1
                start(i,k)=finish(i,k-1);
                finish(i,k)=start(i,k)+weld_time;
            else
                t2=(i-1);
                start(i,k)=max(finish(i,k-1),finish(t2,k));
                totalidletime=totalidletime+start(i,k)-finish(t2,k);
                finish(i,k)=start(i,k)+stime(f_index,k,t)+weld_time;
                SetUp_E=SetUp_E+stime(f_index,k,t)*SetUp_P;
            end
         
            Welding_E=Welding_E+(Idle_P*(1-Kw)+Welding_P*Kw)*weld_time*(worker_n*(1+0.5*log(worker_n)));
        end
    end
end

% Cmax=finish(p_chrom(N),TM);
Cmax=finish(N,NS);
Basic_E=Basic_P*Cmax;
Idle_E=totalidletime*Idle_P;
TEC=Welding_E+Idle_E+SetUp_E+Basic_E;
end

