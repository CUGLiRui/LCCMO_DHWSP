function [p_chrom,w_chrom,f_chrom]=HInitial2(popsize)
global N TM F;
%首先NEH这个插入法是很有效的，但是会消耗过多的评价次数
%如果评价次数一定的情况下，采用启发式构造规则会节省评价次数
%规则1：先把速度都提到最大，那么最大完工时间就会越小
%规则2：把速度降到最低，此时的能耗是最低的
%规则3：累计每个工件的总加工时间，将从大到小排序，随后均衡的分布到各个工厂中使得工厂负载均衡
%规则4：随机初始化

%每个规则 产生ps/4的子种群大小，最后再合并

sub_ps=ceil(popsize/10);
sub_ps2=ceil(popsize/5);
sub_ps3=popsize-sub_ps;
[p_chrom1,w_chrom1,f_chrom1]=RandomRule(sub_ps3);
[p_chrom2,w_chrom2,f_chrom2]=MaxWelderRule(sub_ps);


p_chrom=[p_chrom1;p_chrom2];
w_chrom=[w_chrom1;w_chrom2];
f_chrom=[f_chrom1;f_chrom2];

end

function [p_chrom,v_chrom,f_chrom]=LoadBalanceRule(popsize)
global N NS NM F ptime;
p_chrom=zeros(popsize,N);
f_chrom=zeros(popsize,N);%工序码
P=ones(1,N);FChrom=zeros(1,N);
for i=1:N
    P(i)=i;
%     FChrom(i)=mod(i,F);%0表示分到工厂1,1表示分到工厂2 或者反过来，反正是不一样的工厂。工厂的机器是一样的。
%     if FChrom(i)==0
%         FChrom(i)=F;
%     end
end
p_chrom(1,:)=P(randperm(N));
% f_chrom(1,:)=FChrom(randperm(length(FChrom)));%将工序码打乱
for i=2:popsize
    P=p_chrom(i-1,:);
    p_chrom(i,:)=P(randperm(N));
%     tmp2=f_chrom(i-1,:);
%     f_chrom(i,:)=tmp2(randperm(length(tmp2)));%再根据上一个生成后续的种群个体
end

TotFTime=zeros(F,N);
for f=1:F
    for i=1:N
        for k=1:NS
            TotFTime(f,i)=TotFTime(f,i)+ptime(f,k,i);
        end
    end
end

for n=1:popsize
    f_load=zeros(1,F);
    for i=1:N
        [~,min_f]=min(f_load);
        [~,min_tf]=min(TotFTime(min_f,i));
        if length(min_f)>1
            f_chrom(n,i)=min_f(min_tf);
            x=min_f(min_tf);
            f_load(x)=f_load(x)+TotFTime(x,i);
        else
            f_chrom(n,i)=min_f;
            f_load(min_f)=f_load(min_f)+TotFTime(min_f,i);
        end
    end
end

v_chrom=zeros(popsize,N,NS);
for i=1:popsize
    for j=1:N
        for k=1:NS
            v_chrom(i,j,k)=ceil(rand*NM(k));
        end
    end
end 

end

function [p_chrom,v_chrom,f_chrom]=MaxWelderRule(popsize)
global N NS NM F;
p_chrom=zeros(popsize,N);
f_chrom=zeros(popsize,N);%工序码
P=ones(1,N);FChrom=zeros(1,N);
for i=1:N
    P(i)=i;
    FChrom(i)=mod(i,F);%0表示分到工厂1,1表示分到工厂2 或者反过来，反正是不一样的工厂。工厂的机器是一样的。
    if FChrom(i)==0
        FChrom(i)=F;
    end
end
p_chrom(1,:)=P(randperm(N));
f_chrom(1,:)=FChrom(randperm(length(FChrom)));%将工序码打乱
for i=2:popsize
    P=p_chrom(i-1,:);
    p_chrom(i,:)=P(randperm(N));
    tmp2=f_chrom(i-1,:);
    f_chrom(i,:)=tmp2(randperm(length(tmp2)));%再根据上一个生成后续的种群个体
end

v_chrom=zeros(popsize,N,NS);
for i=1:popsize
    for j=1:N
        for k=1:NS
            v_chrom(i,j,k)=NM(k);
        end
    end
end 

end

function [p_chrom,v_chrom,f_chrom]=MinWelderRule(popsize)
global N NS NM F;
p_chrom=zeros(popsize,N);
f_chrom=zeros(popsize,N);%工序码
P=ones(1,N);FChrom=zeros(1,N);
for i=1:N
    P(i)=i;
    FChrom(i)=mod(i,F);%0表示分到工厂1,1表示分到工厂2 或者反过来，反正是不一样的工厂。工厂的机器是一样的。
    if FChrom(i)==0
        FChrom(i)=F;
    end
end
p_chrom(1,:)=P(randperm(N));
f_chrom(1,:)=FChrom(randperm(length(FChrom)));%将工序码打乱
for i=2:popsize
    P=p_chrom(i-1,:);
    p_chrom(i,:)=P(randperm(N));
    tmp2=f_chrom(i-1,:);
    f_chrom(i,:)=tmp2(randperm(length(tmp2)));%再根据上一个生成后续的种群个体
end

v_chrom=zeros(popsize,N,NS);
for i=1:popsize
    for j=1:N
        for k=1:NS
            v_chrom(i,j,k)=1;
        end
    end
end 

end

function [p_chrom,v_chrom,f_chrom]=RandomRule(popsize)
global N NS NM F;
p_chrom=zeros(popsize,N);
f_chrom=zeros(popsize,N);%工序码
P=ones(1,N);FChrom=zeros(1,N);
for i=1:N
    P(i)=i;
    FChrom(i)=mod(i,F);%0表示分到工厂1,1表示分到工厂2 或者反过来，反正是不一样的工厂。工厂的机器是一样的。
    if FChrom(i)==0
        FChrom(i)=F;
    end
end
p_chrom(1,:)=P(randperm(N));
f_chrom(1,:)=FChrom(randperm(length(FChrom)));%将工序码打乱
for i=2:popsize
    P=p_chrom(i-1,:);
    p_chrom(i,:)=P(randperm(N));
    tmp2=f_chrom(i-1,:);
    f_chrom(i,:)=tmp2(randperm(length(tmp2)));%再根据上一个生成后续的种群个体
end

v_chrom=zeros(popsize,N,NS);
for i=1:popsize
    for j=1:N
        for k=1:NS
            v_chrom(i,j,k)=ceil(rand*NM(k));
        end
    end
end
end
