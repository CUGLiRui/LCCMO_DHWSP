function LocalSearch(p_chrom,v_chrom,f_chrom,fitness,ID)
    global AP AF AV AFit AFlag;
    Fit=zeros(1,3);
    if ID==1
    [np1]=LS1(p_chrom);
    [Fit(1,1),Fit(1,2),Fit(1,3)]=FitDHWSP(np1,v_chrom,f_chrom);
    nr=NDS(Fit,fitness);
    if nr==1||nr==0 %新解支配旧解             
       AP=[AP;np1];
       AV=[AV;v_chrom];         
       AF=[AF;f_chrom];  
       AFit=[AFit;Fit];
       AFlag=[AFlag;0];
    end
    elseif ID==2
        [np3]=LS3(p_chrom,v_chrom,f_chrom,fitness);
    [Fit(1,1),Fit(1,2),Fit(1,3)]=FitDHWSP(np3,v_chrom,f_chrom);
    nr=NDS(Fit,fitness);
    if nr==1||nr==0 %新解支配旧解             
       AP=[AP;np3];
       AV=[AV;v_chrom];         
       AF=[AF;f_chrom];  
       AFit=[AFit;Fit];
       AFlag=[AFlag;0];
    end 
    elseif ID==3
         [np4]=LS4(p_chrom,v_chrom,f_chrom,fitness);
    [Fit(1,1),Fit(1,2),Fit(1,3)]=FitDHWSP(np4,v_chrom,f_chrom);
    nr=NDS(Fit,fitness);
    if nr==1||nr==0 %新解支配旧解             
       AP=[AP;np4];
       AV=[AV;v_chrom];         
       AF=[AF;f_chrom];  
       AFit=[AFit;Fit];
       AFlag=[AFlag;0];
    end
    elseif ID==4
         [nv5]=LS5(p_chrom,v_chrom,f_chrom,fitness);
    [Fit(1,1),Fit(1,2),Fit(1,3)]=FitDHWSP(p_chrom,nv5,f_chrom);
    nr=NDS(Fit,fitness);
    if nr==1||nr==0 %新解支配旧解             
       AP=[AP;p_chrom];
       AV=[AV;nv5];         
       AF=[AF;f_chrom];  
       AFit=[AFit;Fit];
       AFlag=[AFlag;0];
    end
    elseif ID==5
         [nf7]=LS7(f_chrom);
    [Fit(1,1),Fit(1,2),Fit(1,3)]=FitDHWSP(p_chrom,v_chrom,nf7);
    nr=NDS(Fit,fitness);
    if nr==1||nr==0 %新解支配旧解             
       AP=[AP;p_chrom];
       AV=[AV;v_chrom];         
       AF=[AF;nf7];  
       AFit=[AFit;Fit];
       AFlag=[AFlag;0];
    end
    end
    
   
   
    
end

%two point swap
function [p_chrom]=LS1(p_chrom)
global N;
pos1=ceil(rand*N);
pos2=ceil(rand*N);
while pos1==pos2
    pos2=ceil(rand*N);
end
temp=p_chrom(pos1);
p_chrom(pos1)=p_chrom(pos2);
p_chrom(pos2)=temp;
end



%two point swap mutation in critical factory
function [p_chrom]=LS3(p_chrom,v_chrom,f_chrom,fitness)
global N F;
P=cell(F,1);
FJ=cell(F,1);
for i=1:N
    t1=p_chrom(i);%记录到当前是那个工
    t3=f_chrom(t1);
    P{t3}=[P{t3} p_chrom(i)];    
end
for i=1:N
    t3=f_chrom(i);
    FJ{t3}=[FJ{t3} i];    
end
cf=fitness(1,3);
CP=FindCriticalPathDHWSP(P{cf,1},v_chrom,cf);
l=length(CP);
index1=ceil(rand*l);
index2=ceil(rand*l);
CO1=CP(index1,:);CO2=CP(index2,:);
while CO1(1,1)==CO2(1,1)
    index2=ceil(rand*l);
    CO2=CP(index2,:);
end
pos1=find(p_chrom==CO1(1,1));
pos2=find(p_chrom==CO2(1,1));
temp=p_chrom(pos1);
p_chrom(pos1)=p_chrom(pos2);
p_chrom(pos2)=temp;
end

%two point insert mutation in critical factory
function [p_chrom]=LS4(p_chrom,v_chrom,f_chrom,fitness)
global N F;
P=cell(F,1);
FJ=cell(F,1);
for i=1:N
    t1=p_chrom(i);%记录到当前是那个工
    t3=f_chrom(t1);
    P{t3}=[P{t3} p_chrom(i)];    
end
for i=1:N
    t3=f_chrom(i);
    FJ{t3}=[FJ{t3} i];    
end
cf=fitness(1,3);
CP=FindCriticalPathDHWSP(P{cf,1},v_chrom,cf);
l=length(CP);
index1=ceil(rand*l);
index2=ceil(rand*l);
CO1=CP(index1,:);CO2=CP(index2,:);
while CO1(1,1)==CO2(1,1)
    index2=ceil(rand*l);
    CO2=CP(index2,:);
end
pos1=find(p_chrom==CO1(1,1));
pos2=find(p_chrom==CO2(1,1));
low=min(pos1,pos2);
high=max(pos1,pos2);
temp=p_chrom(high);
for i=high:-1:low+1
    p_chrom(i)=p_chrom(i-1);
end
p_chrom(low)=temp;
end

%randomly select a machine and increase speed a level
function [v_chrom]=LS5(p_chrom,v_chrom,f_chrom,fitness)
global N  F;

P=cell(F,1);
FJ=cell(F,1);
for i=1:N
    t1=p_chrom(i);%记录到当前是那个工
    t3=f_chrom(t1);
    P{t3}=[P{t3} p_chrom(i)];    
end
for i=1:N
    t3=f_chrom(i);
    FJ{t3}=[FJ{t3} i];    
end
cf=fitness(1,3);
CP=FindCriticalPathDHWSP(P{cf,1},v_chrom,cf);
l=length(CP);
index=ceil(rand*l);
CO=CP(index,:);
count=0;
while v_chrom(1,CO(1,1),CO(1,2))==5
    index=ceil(rand*l);
    CO=CP(index,:);
    count=count+1;
    if count>l
        break;
    end
end
if v_chrom(1,CO(1,1),CO(1,2))<5
    v_chrom(1,CO(1,1),CO(1,2))=v_chrom(1,CO(1,1),CO(1,2))+1;
else
    v_chrom(1,CO(1,1),CO(1,2))=ceil(rand*5);
end

end


%randomly reselect a factory
function [f_chrom]=LS7(f_chrom)
global N F;
pos1=ceil(rand*N);
cf=f_chrom(pos1);
f=ceil(rand*F);
while cf==f
    f=ceil(rand*F);
    f_chrom(pos1)=f;
end
f_num=zeros(1,F);
for f=1:F
    f_num(1,f)=length(find(f_chrom==f));
end

for f=1:F
    if f_num(1,f)==0
        FChrom=zeros(1,N);
for i=1:N
    FChrom(i)=mod(i,F);%0表示分到工厂1,1表示分到工厂2 或者反过来，反正是不一样的工厂。工厂的机器是一样的。
    if FChrom(i)==0
       FChrom(i)=F;
    end       
end
%         fprintf('factory %d is zeros 1',f)
        f_chrom=FChrom(randperm(N));%将工序码打乱
    end
end
end