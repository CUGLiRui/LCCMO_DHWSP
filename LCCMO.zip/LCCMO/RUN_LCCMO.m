clc
clear all

FILENAME={'20J2F2S.txt','20J2F5S.txt','20J3F2S.txt','20J3F5S.txt',...
          '40J2F2S.txt','40J2F5S.txt','40J3F2S.txt','40J3F5S.txt',...
          '60J2F2S.txt','60J2F5S.txt','60J3F2S.txt','60J3F5S.txt',...
          '80J2F2S.txt','80J2F5S.txt','80J3F2S.txt','80J3F5S.txt',...
          '100J2F2S.txt','100J2F5S.txt','100J3F2S.txt','100J3F5S.txt'};
filenum=20;
runtime=10;
global N NS F NM stime ptime ps AP AF AV AFit AFlag;
ps=100;Pc=1.0;Pm=0.2;
Pc=1.0;Pm=0.2;epsilon=0.95;alpha=0.1;gamma=0.9;
DATAPATH='..\DATASET_DHWSP\';
INSPATH={};
for file=1:filenum
    INSPATH{file}=[DATAPATH,FILENAME{file}];
    if file<10
        id=['0',num2str(file)];
    else
        id=num2str(file);
    end
    RESPATH{file}=['DHPFSP',id,'\'];
end

for file=14:filenum
    [N,NS,F,NM,stime,ptime]=DATAREAD_DHWSP(INSPATH{file});
    MaxNFEs=400*N;%最大评价次数
    if MaxNFEs<20000
        MaxNFEs=20000;
    end 
    respath='LCCMO\';
    tmp6='\';
    respath=[respath,RESPATH{file},tmp6];
    %清除无关变量
    clear tmp6
    a=['mkdir ' respath];%创立写结果的文件夹
    system(a);%利用Windows命令行命令执行dos命令
    fprintf('%s %s\r\n','Calculating ',FILENAME{1,file});
    subps1=ps;subps2=ps/5;
    for round=1:runtime
        AP=[];AF=[]; AV=[];AFit=[];AFlag=[];
        
        %population 1 execute CCSPEA2
        [p_chrom1,w_chrom1,f_chrom1]=HInitial(subps1);
         fitness1=zeros(ps,3);
        NFEs=0;
        for i=1:ps
            [fitness1(i,1),fitness1(i,2),fitness1(i,3)]=FitDHWSP(p_chrom1(i,:),w_chrom1(i,:,:),f_chrom1(i,:));
        end 
        i=1;
        
        %population 2 execute SPEA2
        [p_chrom2,w_chrom2,f_chrom2]=HInitial(subps2);
        fitness2=zeros(subps2,3);
        NFEs=0;
        for i=1:subps2
            [fitness2(i,1),fitness2(i,2),fitness2(i,3)]=FitDHWSP(p_chrom2(i,:),w_chrom2(i,:,:),f_chrom2(i,:));
        end 
        
        
        i=1;
        QTable1=zeros(10,5);
        CS1=1;      
        while NFEs<MaxNFEs %transfer
        fprintf('%s %s %d %s %d\r\n',FILENAME{1,file},'round',round,'iter',i);
        i=i+1;
        
        %population 1 execute CCSPEA2
        [CP1,CV1,CF1,CFit1]=CCEA_SPEA2(p_chrom1,w_chrom1,f_chrom1,fitness1,Pc,Pm,subps1);
        NFEs=NFEs+ps;
        %population 2 execute SPEA2
        [PF1,~]=pareto1(p_chrom2);
        L=length(PF1);
        for k=1:L
            if rand>epsilon
                R=ceil(rand*5);
            else
                [~,Ac]=max(QTable1(CS1,:));
                acl=length(Ac);
                if acl>1
                    R=Ac(ceil(rand*acl));
                else
                    R=Ac;
                end
            end      
            if R==1
               ID=1;
            elseif R==2
               ID=2;
            elseif R==3
               ID=3;
            elseif R==4
               ID=4;
            elseif R==5
               ID=5;
            end   
            j=PF1(k);
            [p_chrom2(j,:),w_chrom2(j,:,:),f_chrom2(j,:),fitness2(j,:),flag1]=LocalSearch2(p_chrom2(j,:),w_chrom2(j,:,:),f_chrom2(j,:),fitness2(j,:),ID);
            NFEs=NFEs+1;
            if flag1==0
                reward1=10;
            else
                reward1=0;
            end
            NS1=R*2-1+flag1;
            maxreward=max(QTable1(NS1,:));%找到下一状态最大的回报 表示所有的动作都是可能的动作
            Qtarget=reward1+gamma*maxreward;   %计算Q下一个状态的估计值
            QTable1(CS1,R)=QTable1(CS1,R)+alpha*(Qtarget- QTable1(CS1,R));%更新Q矩阵
            CS1=NS1;
         end
%         [CP2,CV2,CF2,CFit2]=CCEA_SPEA2(p_chrom2,v_chrom2,f_chrom2,fitness2,Pc,Pm,subps2);           
         CP2=p_chrom2;CV2=w_chrom2;CF2=f_chrom2;CFit2=fitness2;
        
        %for task1
        [p_chrom1,w_chrom1,f_chrom1,fitness1,~] = EnSelectionCCSPEA2([CP1],[CV1],[CF1],[CFit1],subps1);
    
        
        %for task2
        [p_chrom2,w_chrom2,f_chrom2,fitness2,~] = EnSelectionCCSPEA2([CP2],[CV2],[CF2],[CFit2],subps2);
        
        
        %elite strategy
        QP=[p_chrom1;p_chrom2];
        QV=[w_chrom1;w_chrom2];
        QF=[f_chrom1;f_chrom2];
        QFit=[fitness1;fitness2];
        
        
        [PF,~]=pareto1(QFit);
        AP=[AP;QP(PF,:)];AF=[AF;QF(PF,:)];   
        AV=[AV;QV(PF,:,:)];AFit=[AFit;QFit(PF,:)];AFlag=[AFlag;zeros(length(PF),1)];
        [PF,~]=pareto1(AFit);
        AP=AP(PF,:);AFit=AFit(PF,:);AV=AV(PF,:,:);AF=AF(PF,:);AFlag=AFlag(PF,:);
        DeleteRpeat2();
        
        %elite local search
        al=size(AP,1);
        for j=1:al
            R=ceil(rand*5);
            if R==1
               LocalSearch(AP(j,:),AV(j,:,:),AF(j,:),AFit(j,:),1);
            elseif R==2
               LocalSearch(AP(j,:),AV(j,:,:),AF(j,:),AFit(j,:),2);
            elseif R==3
               LocalSearch(AP(j,:),AV(j,:,:),AF(j,:),AFit(j,:),3);
            elseif R==4
               LocalSearch(AP(j,:),AV(j,:,:),AF(j,:),AFit(j,:),4);
            elseif R==5
               LocalSearch(AP(j,:),AV(j,:,:),AF(j,:),AFit(j,:),5);
            end        
            NFEs=NFEs+1;
        end
        [PF,~]=pareto1(AFit);
        AP=AP(PF,:);AFit=AFit(PF,:);AV=AV(PF,:,:);AF=AF(PF,:);AFlag=AFlag(PF,:);
        
%         %elite energy_save
%         if NFEs>MaxNFEs*0.9
%             az=find(AFlag==0);
%             al=length(az);
%             P1=zeros(al,N);V1=zeros(al,N,TM);F1=zeros(al,N);
%             parfor j=1:al
%                 [P1(j,:),V1(j,:,:),F1(j,:)]=EnergySave3_DHPFSP(AP(az(j),:),AV(az(j),:,:),AF(az(j),:));              
%             end         
%             for j=1:al
%                 [Fit(1,1),Fit(1,2),Fit(1,3)]=FitDHPFSP(P1(j,:),V1(j,:,:),F1(j,:));
%                 NFEs=NFEs+1;
%                 t=az(j);
%                 AFlag(t,1)=1;
%                 nr=NDS(Fit,AFit(t,:));
%                 if nr==1 %新解支配旧解
%                     AP(t,:)=P1(j,:);
%                     AV(t,:,:)=V1(j,:,:);
%                     AF(t,:)=F1(j,:);
%                     AFit(t,:)=Fit;
%                     AFlag(t,1)=0;
%                 elseif nr==0 &&(Fit(1,1)~=AFit(t,1))&&(Fit(1,2)~=AFit(t,2))
%                     AP=[AP;P1(j,:)];
%                     AV=[AV;V1(j,:,:)];         
%                     AF=[AF;F1(j,:)];  
%                     AFit=[AFit;Fit];
%                     AFlag=[AFlag;0];
%                 end
%             end 
%         [PF,~]=pareto1(AFit);
%         AP=AP(PF,:);AFit=AFit(PF,:);AV=AV(PF,:,:);AF=AF(PF,:);AFlag=AFlag(PF,:);
%         end%IF END 
        
        end%WHILE END
    
        
    [PF,~]=pareto1(AFit);
    L=length(PF);
    obj=AFit(:,1:2);
    newobj=[];
    for i=1:L
        newobj(i,:)=obj(PF(i),:);   
    end
    newobj=unique(newobj,'rows');%删除重复行
    tmp5=newobj';%将求得的前沿解集转置
    %scatter(newobj(:,1),newobj(:,2));
    tmp1='res';%根据字符串编写出结果存储的路径
    resPATH=[respath tmp1 num2str(round) '.txt'];
    fout=fopen(resPATH,'w');
    fprintf(fout,'%5.2f %6.3f\r\n',tmp5);%由于matlab是按照列存储和读取矩阵，则写入文件的时候也是按照列填写，因此要转置存入
    fclose(fout);
   end

end

